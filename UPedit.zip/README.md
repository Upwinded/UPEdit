# UPEdit
An Editor for All Heroes of Kam Yung's Stories


  Upwinded Editor(UPedit)
  An Editor--Special for All Heroes in Kam Yung's Stories
  Created by Upwinded.L.
  ©2011 Upwinded.L. Some rights reserved.



  You can build it with delphi2010, with some parts supported by XLSreadwriteII.
  Anybody who gets this source code is able to modify or rebuild it anyway,
  but please keep this section when you want to spread a new version.



  你可以用delphi2010编译这些代码，其中一部分要用到XLSreadwriteII这个第三方控件。
  任何得到此代码的人都可以修改或者重新编译这段代码，但是请保留这段文字。


  Upwinded.L.(281184040@qq.com), in 2011 April. 
  
  -----------------
  以下是sb500的补充
  
  xls支持的列数最多到256，改用tms flexcel可以支持xlsx。
  后该插件过期，改为自己手动写xlsxio和libxlsxwriter的pas文件。
